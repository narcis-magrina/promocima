-- ═══════════════════════════════════════════════════════════════════════════════
--  V1.0002 — PKs COMPUESTAS (empresa_id, id)
--  IMPORTANTE: Ejecutar con la app parada y tras hacer backup
-- ═══════════════════════════════════════════════════════════════════════════════

-- ── 1. Eliminar TODAS las FKs de tablas afectadas dinámicamente ──────────────
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN
    SELECT tc.constraint_name, tc.table_name
    FROM information_schema.table_constraints tc
    WHERE tc.constraint_type = 'FOREIGN KEY'
      AND tc.table_schema = 'public'
      AND tc.table_name IN (
        'clientes','intermediarios','participes','prestamos',
        'cobros','contratos_ccp','pagos_reales_participe',
        'titulares','config','perfiles','BdE_Operaciones'
      )
  LOOP
    EXECUTE format('ALTER TABLE %I DROP CONSTRAINT IF EXISTS %I CASCADE',
                   r.table_name, r.constraint_name);
  END LOOP;
END$$;

-- ── 2. Eliminar TODAS las PKs de tablas afectadas dinámicamente ──────────────
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN
    SELECT tc.constraint_name, tc.table_name
    FROM information_schema.table_constraints tc
    WHERE tc.constraint_type = 'PRIMARY KEY'
      AND tc.table_schema = 'public'
      AND tc.table_name IN (
        'clientes','intermediarios','participes','prestamos',
        'cobros','contratos_ccp','pagos_reales_participe',
        'titulares','config'
      )
  LOOP
    EXECUTE format('ALTER TABLE %I DROP CONSTRAINT %I CASCADE',
                   r.table_name, r.constraint_name);
  END LOOP;
END$$;

-- ── 3. Crear nuevas PKs compuestas (empresa_id, id) ──────────────────────────
ALTER TABLE clientes               ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE intermediarios         ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE participes             ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE prestamos              ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE cobros                 ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE contratos_ccp          ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE pagos_reales_participe ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE titulares              ADD PRIMARY KEY (empresa_id, id);
ALTER TABLE config                 ADD PRIMARY KEY (empresa_id, id);

-- ── 4. Recrear FKs compuestas ────────────────────────────────────────────────

-- clientes → empresas
ALTER TABLE clientes ADD CONSTRAINT clientes_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);

-- intermediarios → empresas
ALTER TABLE intermediarios ADD CONSTRAINT intermediarios_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);

-- participes → empresas
ALTER TABLE participes ADD CONSTRAINT participes_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);

-- titulares → empresas + clientes (compuesta)
ALTER TABLE titulares ADD CONSTRAINT titulares_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);
ALTER TABLE titulares ADD CONSTRAINT titulares_cliente_fkey
  FOREIGN KEY (empresa_id, cliente_id) REFERENCES clientes(empresa_id, id);

-- prestamos → empresas + clientes (compuesta) + intermediarios (compuesta)
ALTER TABLE prestamos ADD CONSTRAINT prestamos_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);
ALTER TABLE prestamos ADD CONSTRAINT prestamos_cliente_fkey
  FOREIGN KEY (empresa_id, cliente_id) REFERENCES clientes(empresa_id, id);
ALTER TABLE prestamos ADD CONSTRAINT prestamos_intermediario_fkey
  FOREIGN KEY (empresa_id, intermediario_id) REFERENCES intermediarios(empresa_id, id)
  DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE prestamos ADD CONSTRAINT prestamos_origen_prestamo_fkey
  FOREIGN KEY (empresa_id, origen_prestamo_id) REFERENCES prestamos(empresa_id, id)
  DEFERRABLE INITIALLY DEFERRED;

-- cobros → empresas + prestamos (compuesta)
ALTER TABLE cobros ADD CONSTRAINT cobros_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);
ALTER TABLE cobros ADD CONSTRAINT cobros_prestamo_fkey
  FOREIGN KEY (empresa_id, prestamo_id) REFERENCES prestamos(empresa_id, id);

-- contratos_ccp → empresas + prestamos (compuesta) + participes (compuesta)
ALTER TABLE contratos_ccp ADD CONSTRAINT contratos_ccp_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);
ALTER TABLE contratos_ccp ADD CONSTRAINT contratos_ccp_prestamo_fkey
  FOREIGN KEY (empresa_id, prestamo_id) REFERENCES prestamos(empresa_id, id);
ALTER TABLE contratos_ccp ADD CONSTRAINT contratos_ccp_participe_fkey
  FOREIGN KEY (empresa_id, participe_id) REFERENCES participes(empresa_id, id);

-- pagos_reales_participe → empresas + contratos_ccp (compuesta)
ALTER TABLE pagos_reales_participe ADD CONSTRAINT pagos_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);
ALTER TABLE pagos_reales_participe ADD CONSTRAINT pagos_contrato_ccp_fkey
  FOREIGN KEY (empresa_id, contrato_ccp_id) REFERENCES contratos_ccp(empresa_id, id);

-- config → empresas
ALTER TABLE config ADD CONSTRAINT config_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);

-- perfiles → empresas (participe_id es array, no se puede FK formal)
ALTER TABLE perfiles ADD CONSTRAINT perfiles_empresa_id_fkey
  FOREIGN KEY (empresa_id) REFERENCES empresas(id);

-- ── 5. Añadir empresa_id a BdE_Operaciones ───────────────────────────────────
ALTER TABLE "BdE_Operaciones" ADD COLUMN IF NOT EXISTS empresa_id text;
UPDATE "BdE_Operaciones" SET empresa_id = 'PROMOCIMA' WHERE empresa_id IS NULL;

-- ── 6. Verificación final ─────────────────────────────────────────────────────
SELECT
  tc.table_name,
  tc.constraint_type,
  string_agg(kcu.column_name, ', ' ORDER BY kcu.ordinal_position) AS columns
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema = kcu.table_schema
WHERE tc.table_schema = 'public'
  AND tc.constraint_type IN ('PRIMARY KEY')
  AND tc.table_name IN ('clientes','intermediarios','participes','prestamos',
                        'cobros','contratos_ccp','pagos_reales_participe',
                        'titulares','config')
GROUP BY tc.table_name, tc.constraint_type
ORDER BY tc.table_name;
